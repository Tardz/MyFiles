def div_by_three(n):
    result = n/3
    print(n, "divided by 3 equals", result)
    return result%1 == 0 

div_by_three(6)