x = int(((40+9)/10))*10
print(x)